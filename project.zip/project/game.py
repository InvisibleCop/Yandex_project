import pygame
import os
import sys
import random
from PIL import Image, ImageDraw


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Не удаётся загрузить:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    return image


pygame.init()
size = width, height = 1280, 720
screen = pygame.display.set_mode(size)
sprite_group = pygame.sprite.Group()
hero_group = pygame.sprite.Group()
entity_group = pygame.sprite.Group()
hpbar_group = pygame.sprite.Group()

tile_images = {'wall1': load_image('7.png'),
               'wall2': load_image('8.png'),
               'wall3': load_image('9.png'),
               'brick': load_image('brick.png'),
               'empty': load_image('11.png')}
player_image = load_image('knight.png')
enemy_image = load_image('skelet.png')

tile_width = tile_height = 80


class ScreenFrame(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.rect = pygame.Rect(0, 0, 500, 500)


class SpriteGroup(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

    def get_event(self, event):
        for i in self:
            i.get_event(event)


class Sprite(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)
        self.rect = None

    def get_event(self, event):
        pass


class Tile(Sprite):
    def __init__(self, tile_type, pos_x, pos_y, mask=-1):
        super().__init__(sprite_group)
        if mask == -1:
            self.image = tile_images[tile_type]
            self.rect = self.image.get_rect().move(tile_width * pos_x, tile_height * pos_y)
        else:
            x, y = mask // 4, mask % 4
            self.image = tile_images[tile_type].subsurface(pygame.Rect(x * 80, y * 80, 80, 80))
            self.rect = self.image.get_rect().move(tile_width * pos_x, tile_height * pos_y)


class Player(Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(hero_group)
        self.image = player_image.subsurface(pygame.Rect(64, 0, 64, 64))
        self.rect = self.image.get_rect().move(tile_width * pos_x + 8, tile_height * pos_y + 8)
        self.pos = (pos_x, pos_y)
        self.hpbar = PlayerHP()
        self.hp = 20
        self.regen = 0.1
        self.maxhp = 20.0

    def move(self, x, y):
        self.pos = (x, y)
        self.hp = round(min(self.maxhp, self.regen + self.hp), 1)
        self.hpbar.change(int(self.hp / self.maxhp * 100))

    def rotate(self, direction):
        if direction == 'up':
            self.image = player_image.subsurface(pygame.Rect(64, 192, 64, 64))
        elif direction == 'right':
            self.image = player_image.subsurface(pygame.Rect(64, 128, 64, 64))
        elif direction == 'left':
            self.image = player_image.subsurface(pygame.Rect(64, 64, 64, 64))
        elif direction == 'down':
            self.image = player_image.subsurface(pygame.Rect(64, 0, 64, 64))

    def damage(self):
        damage = random.randint(1, 3)
        self.hp -= damage
        self.hpbar.change(int(self.hp / self.maxhp * 100))
        self.check()

    def check(self):
        if self.hp <= 0:
            pass


class Enemy(Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(entity_group)
        self.image = enemy_image.subsurface(pygame.Rect(64, 0, 64, 64))
        self.rect = self.image.get_rect().move(tile_width * pos_x + 8, tile_height * pos_y + 8)
        self.pos = (pos_x, pos_y)
        self.hp = 5
        self.maxhp = 5
        self.hpbar = HPBar(self.rect.x, self.rect.y)

    def damage(self):
        damage = random.randint(1, 3)
        self.hp -= damage
        self.hpbar.change(int(self.hp / self.maxhp * 100), self.rect.x, self.rect.y)
        self.check()

    def check(self):
        global lvl_enemies
        if self.hp <= 0:
            level_map[self.pos[1]][self.pos[0]] = '.'
            self.hpbar.kill()
            self.kill()

    def action(self):
        global hero, level_map
        hero_x, hero_y = hero.pos
        x, y = self.pos
        if max(abs(x - hero_x), abs(y - hero_y)) <= 1:
            hero.damage()
        elif max(abs(x - hero_x), abs(y - hero_y)) <= 5:
            if abs(x - hero_x) <= abs(y - hero_y) and abs(x - hero_x) != 0 or abs(y - hero_y) == 0:
                sgn = abs(x - hero_x) // (x - hero_x)
                if sgn < 0:
                    if level_map[y][x+1] == '.':
                        self.move('right')
                    else:
                        try:
                            sgn2 = abs(y - hero_y) // (y - hero_y)
                        except ZeroDivisionError:
                            sgn2 = 0
                        if sgn2 < 0:
                            self.move('down')
                        else:
                            self.move('up')
                else:
                    if level_map[y][x-1] == '.':
                        self.move('left')
                    else:
                        try:
                            sgn2 = abs(y - hero_y) // (y - hero_y)
                        except ZeroDivisionError:
                            sgn2 = 0
                        if sgn2 < 0:
                            self.move('down')
                        else:
                            self.move('up')
            elif abs(x - hero_x) > abs(y - hero_y) != 0 or abs(x - hero_x) == 0:
                sgn = abs(y - hero_y) // (y - hero_y)
                if sgn < 0:
                    if level_map[y+1][x] == '.':
                        self.move('down')
                    else:
                        try:
                            sgn2 = abs(x - hero_x) // (x - hero_x)
                        except ZeroDivisionError:
                            sgn2 = 0
                        if sgn2 < 0:
                            self.move('right')
                        else:
                            self.move('left')
                else:
                    if level_map[y-1][x] == '.':
                        self.move('up')
                    else:
                        try:
                            sgn2 = abs(x - hero_x) // (x - hero_x)
                        except ZeroDivisionError:
                            sgn2 = 0
                        if sgn2 < 0:
                            self.move('right')
                        else:
                            self.move('left')
        else:
            pass

    def rotate(self, direction):
        if direction == 'up':
            self.image = enemy_image.subsurface(pygame.Rect(64, 192, 64, 64))
        elif direction == 'right':
            self.image = enemy_image.subsurface(pygame.Rect(64, 128, 64, 64))
        elif direction == 'left':
            self.image = enemy_image.subsurface(pygame.Rect(64, 64, 64, 64))
        elif direction == 'down':
            self.image = enemy_image.subsurface(pygame.Rect(64, 0, 64, 64))

    def move(self, direction):
        global level_map, lvl_enemies
        x, y = self.pos
        if direction == 'left':
            if level_map[y][x - 1] == '.':
                self.rotate('left')
                self.pos = (x - 1, y)
                self.rect.x -= tile_width
                level_map[y][x - 1] = 'E'
                level_map[y][x] = '.'
            elif level_map[y - 1][x] == '.':
                self.pos = (x, y - 1)
                self.rotate('up')
                self.rect.y -= tile_width
                level_map[y - 1][x] = 'E'
                level_map[y][x] = '.'
            elif level_map[y + 1][x] == '.':
                self.pos = (x, y + 1)
                self.rotate('down')
                self.rect.y += tile_width
                level_map[y + 1][x] = 'E'
                level_map[y][x] = '.'
            elif level_map[y][x + 1] == '.':
                self.pos = (x + 1, y)
                self.rotate('right')
                self.rect.x += tile_width
                level_map[y][x + 1] = 'E'
                level_map[y][x] = '.'
        elif direction == 'right':
            if level_map[y][x + 1] == '.':
                self.pos = (x + 1, y)
                self.rotate('right')
                self.rect.x += tile_width
                level_map[y][x + 1] = 'E'
                level_map[y][x] = '.'
            elif level_map[y - 1][x] == '.':
                self.pos = (x, y - 1)
                self.rotate('up')
                self.rect.y -= tile_width
                level_map[y - 1][x] = 'E'
                level_map[y][x] = '.'
            elif level_map[y + 1][x] == '.':
                self.pos = (x, y + 1)
                self.rotate('down')
                self.rect.y += tile_width
                level_map[y + 1][x] = 'E'
                level_map[y][x] = '.'
            elif level_map[y][x - 1] == '.':
                self.pos = (x - 1, y)
                self.rotate('left')
                self.rect.x -= tile_width
                level_map[y][x - 1] = 'E'
                level_map[y][x] = '.'
        elif direction == 'up':
            if level_map[y - 1][x] == '.':
                self.pos = (x, y - 1)
                self.rotate('up')
                self.rect.y -= tile_width
                level_map[y - 1][x] = 'E'
                level_map[y][x] = '.'
            elif level_map[y][x - 1] == '.':
                self.pos = (x - 1, y)
                self.rotate('left')
                self.rect.x -= tile_width
                level_map[y][x - 1] = 'E'
                level_map[y][x] = '.'
            elif level_map[y][x + 1] == '.':
                self.pos = (x + 1, y)
                self.rotate('right')
                self.rect.x += tile_width
                level_map[y][x + 1] = 'E'
                level_map[y][x] = '.'
            elif level_map[y + 1][x] == '.':
                self.pos = (x, y + 1)
                self.rotate('down')
                self.rect.y += tile_width
                level_map[y + 1][x] = 'E'
                level_map[y][x] = '.'
        elif direction == 'down':
            if level_map[y + 1][x] == '.':
                self.pos = (x, y + 1)
                self.rotate('down')
                self.rect.y += tile_width
                level_map[y + 1][x] = 'E'
                level_map[y][x] = '.'
            elif level_map[y][x - 1] == '.':
                self.pos = (x - 1, y)
                self.rotate('left')
                self.rect.x -= tile_width
                level_map[y][x - 1] = 'E'
                level_map[y][x] = '.'
            elif level_map[y][x + 1] == '.':
                self.pos = (x + 1, y)
                self.rotate('right')
                self.rect.x += tile_width
                level_map[y][x + 1] = 'E'
                level_map[y][x] = '.'
            elif level_map[y - 1][x] == '.':
                self.pos = (x, y - 1)
                self.rotate('up')
                self.rect.y -= tile_width
                level_map[y - 1][x] = 'E'
                level_map[y][x] = '.'
        self.hpbar.change(int(self.hp / self.maxhp * 100), self.rect.x, self.rect.y)


class HPBar(pygame.sprite.Sprite):
    def __init__(self, x_spr, y_spr):
        super().__init__(entity_group)
        self.im = Image.new("RGB", (52, 12), "black")
        self.draw = ImageDraw.Draw(self.im)
        self.draw.rectangle([1, 1, 50, 10], fill=(0, 255, 0))
        self.image = pygame.image.fromstring(self.im.tobytes(), self.im.size, self.im.mode)
        self.rect = pygame.Rect(x_spr + 7, y_spr - 15, 52, 12)

    def change(self, percentage, x_, y_):
        self.im = Image.new("RGB", (52, 12), "black")
        self.draw = ImageDraw.Draw(self.im)
        self.draw.rectangle([1, 1, 50, 10], fill=(255, 0, 0))
        self.draw.rectangle([1, 1, max(0, percentage // 2), 10], fill=(0, 255, 0))
        self.image = pygame.image.fromstring(self.im.tobytes(), self.im.size, self.im.mode)
        self.rect = pygame.Rect(x_ + 7, y_ - 15, 52, 12)


class PlayerHP(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(hero_group)
        self.rect = pygame.Rect(0, 0, 210, 50)
        self.im = Image.new("RGB", (210, 50), "blue")
        self.draw = ImageDraw.Draw(self.im)
        self.draw.rectangle([4, 5, 205, 45], fill=(0, 255, 0))
        self.image = pygame.image.fromstring(self.im.tobytes(), self.im.size, self.im.mode)

    def change(self, percentage):
        self.im = Image.new("RGB", (210, 50), "blue")
        self.draw = ImageDraw.Draw(self.im)
        self.draw.rectangle([4, 5, 205, 45], fill=(255, 0, 0))
        self.draw.rectangle([4, 5, 4 + max(0, percentage * 2), 45], fill=(0, 255, 0))
        self.image = pygame.image.fromstring(self.im.tobytes(), self.im.size, self.im.mode)


class Switch(Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(entity_group)
        self.rect = pygame.Rect(pos_x * tile_width, pos_y * tile_height, 80, 80)
        self.image = load_image('switch.png')
        self.pos = (pos_x, pos_y)


class EndSwitch(Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(entity_group)
        self.rect = pygame.Rect(pos_x * tile_width, pos_y * tile_height, 80, 80)
        self.image = load_image('end.png')
        self.pos = (pos_x, pos_y)


def move_obj(direction):
    dx, dy = 0, 0
    if direction == 'up':
        dx, dy = 0, 1
    elif direction == 'right':
        dx, dy = -1, 0
    elif direction == 'left':
        dx, dy = 1, 0
    elif direction == 'down':
        dx, dy = 0, -1
    for spr in sprite_group:
        spr.rect.x += dx * tile_width
        spr.rect.y += dy * tile_height
    for ent in entity_group:
        ent.rect.x += dx * tile_width
        ent.rect.y += dy * tile_height


def calibrate(target):
    x, y = target.rect.x, target.rect.y
    dx, dy = width // 2 - target.rect.w // 2 - x, height // 2 - target.rect.h // 2 - y
    target.rect.x = width // 2 - target.rect.w // 2
    target.rect.y = height // 2 - target.rect.h // 2
    for spr in sprite_group:
        spr.rect.x += dx
        spr.rect.y += dy
    for ent in entity_group:
        ent.rect.x += dx
        ent.rect.y += dy


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    fon = load_image('start.png')
    screen.blit(fon, (0, 0))

    while True:
        for event_ in pygame.event.get():
            if event_.type == pygame.QUIT:
                terminate()
            elif event_.type == pygame.KEYDOWN or event_.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()


def load_level(filename):
    filename = 'data/' + filename
    with open(filename, 'r') as mapFile:
        level_map_ = [line.strip() for line in mapFile]
    max_width = max(map(len, level_map_))
    return list(map(lambda x: list(x.ljust(max_width, 'v')), level_map_))


def generate_level(level):
    switches_count_ = 0
    mask_type = random.randint(1, 3)
    new_player, x, y, enemies, switches = None, None, None, list(), list()
    for y in range(len(level)):
        for x in range(len(level[y])):
            mask = random.randint(0, 15)
            if level[y][x] == '.':
                Tile('empty', x, y, mask)
            elif level[y][x] == '#':
                mask = random.randint(0, 15)
                Tile(f'{"wall" + str(mask_type)}', x, y, mask)
                # Tile('brick', x, y)
            elif level[y][x] == '@':
                Tile('empty', x, y, mask)
                new_player = Player(x, y)
                level[y][x] = '.'
            elif level[y][x] == "v":
                pass
            elif level[y][x] == "E":
                Tile('empty', x, y, mask)
                new_enemy = Enemy(x, y)
                enemies.append(new_enemy)
            elif level[y][x] == 's':
                Tile('empty', x, y, mask)
                new_switch = Switch(x, y)
                switches.append(new_switch)
                switches_count_ += 1
            elif level[y][x] == 'S':
                Tile('empty', x, y, mask)
                EndSwitch(x, y)
            else:
                pass
    return new_player, x, y, enemies, switches, switches_count_


def move(hero, movement):
    x, y = hero.pos
    global act, switches_tapped, switches_count
    hero.rotate(movement)
    if movement == 'up':
        if y > 0 and level_map[y-1][x] == '.':
            hero.move(x, y - 1)
            move_obj(movement)
            act += 1
        if y > 0 and level_map[y-1][x] == 's':
            hero.move(x, y - 1)
            move_obj(movement)
            act += 1
            for sw in lvl_switches:
                if sw.pos == (x, y - 1):
                    switches_tapped += 1
                    level_map[y - 1][x] = '.'
                    sw.kill()
        if y > 0 and level_map[y - 1][x] == 'S':
            if switches_tapped == switches_count:
                terminate()
    if movement == 'down':
        if y > 0 and level_map[y+1][x] == '.':
            hero.move(x, y + 1)
            move_obj(movement)
            act += 1
        if y > 0 and level_map[y+1][x] == 's':
            hero.move(x, y + 1)
            move_obj(movement)
            act += 1
            for sw in lvl_switches:
                if sw.pos == (x, y + 1):
                    switches_tapped += 1
                    level_map[y + 1][x] = '.'
                    sw.kill()
        if y > 0 and level_map[y + 1][x] == 'S':
            if switches_tapped == switches_count:
                terminate()
    if movement == 'left':
        if x > 0 and level_map[y][x-1] == '.':
            hero.move(x - 1, y)
            move_obj(movement)
            act += 1
        if x > 0 and level_map[y][x-1] == 's':
            hero.move(x - 1, y)
            move_obj(movement)
            act += 1
            for sw in lvl_switches:
                if sw.pos == (x - 1, y):
                    switches_tapped += 1
                    level_map[y][x - 1] = '.'
                    sw.kill()
        if x > 0 and level_map[y][x - 1] == 'S':
            if switches_tapped == switches_count:
                terminate()
    if movement == 'right':
        if x > 0 and level_map[y][x+1] == '.':
            hero.move(x + 1, y)
            move_obj(movement)
            act += 1
        if x > 0 and level_map[y][x+1] == 's':
            hero.move(x + 1, y)
            move_obj(movement)
            act += 1
            for sw in lvl_switches:
                if sw.pos == (x + 1, y):
                    switches_tapped += 1
                    level_map[y][x + 1] = '.'
                    sw.kill()
        if x > 0 and level_map[y][x + 1] == 'S':
            if switches_tapped == switches_count:
                terminate()


def get_cell(pos):
    x, y = pos
    x = x - 600
    y = y - 320
    return x // 80, y // 80


def begin():
    global level_map
    global hero, max_x, max_y, lvl_enemies, lvl_switches, switches_count, switches_tapped
    global act
    running = True
    level_map = load_level('1.txt')
    switches_tapped = 0
    hero, max_x, max_y, lvl_enemies, lvl_switches, switches_count = generate_level(level_map)
    calibrate(hero)
    clock = pygame.time.Clock()
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif act == 0:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP or event.key == pygame.K_w:
                        move(hero, 'up')
                    elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                        move(hero, 'down')
                    elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                        move(hero, 'left')
                    elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                        move(hero, 'right')
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    evx, evy = get_cell(event.pos)
                    if max(abs(evx), abs(evy)) == 1:
                        if level_map[evy + hero.pos[1]][evx + hero.pos[0]] == "E":
                            for enemy in lvl_enemies:
                                if enemy.pos == (evx + hero.pos[0], evy + hero.pos[1]) and enemy.alive():
                                    enemy.damage()
                                    act += 1
                while act != 0:
                    for enemy in lvl_enemies:
                        if enemy.alive():
                            enemy.action()
                    act -= 1
        screen.fill(pygame.Color('black'))
        sprite_group.draw(screen)
        hero_group.draw(screen)
        entity_group.draw(screen)
        hpbar_group.draw(screen)
        clock.tick(60)
        pygame.display.flip()
        if hero.hp <= 0:
            running = False
    return


def dead():
    global player
    global level_map
    global hero, max_x, max_y, lvl_enemies, lvl_switches, switches_count, switches_tapped
    global act
    player = None
    switches_count = 0
    level_map = list(list())
    switches_tapped = 0
    hero, max_x, max_y, lvl_enemies, lvl_switches, switches_count = None, None, None, list(), list(), 0
    act = 0
    screen.fill(pygame.Color('black'))
    sprite_group.empty()
    hero_group.empty()
    entity_group.empty()
    hpbar_group.empty()

    fon = load_image('death.png')
    screen.blit(fon, (0, 0))

    while True:
        for event_ in pygame.event.get():
            if event_.type == pygame.QUIT:
                terminate()
            elif event_.type == pygame.KEYDOWN or event_.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()


if __name__ == '__main__':
    pygame.display.set_caption('Игра')
    player = None
    level_map = list(list())
    hero, max_x, max_y, lvl_enemies, lvl_switches, switches_count = None, None, None, list(), list(), 0
    switches_tapped = 0
    act = 0
    start_screen()
    while True:
        begin()
        dead()
        start_screen()

